
document.addEventListener('DOMContentLoaded', function(){
    document.querySelector('.mfClose').addEventListener('click',()=>window.close());
});


