'use strict';
//https://stackoverflow.com/questions/59903262/how-in-joomla-with-api-with-ajax-get-field-editor-for-form
//https://stackoverflow.com/questions/6547116/joomla-jce-editor-not-loading-in-page-loaded-with-ajax?rq=1
jQuery(document).on( 'scroll', function(){
	scrollFromTop();
});

function scrollFromTop(){
	var fff = window.pageYOffset || document.documentElement.scrollTop;
	return fff;
}

function positionAfterSend(heightblock){
    var heightpage = jQuery(window).height();
	var heightpopupblock 	= jQuery(heightblock).height();
	var scrollFT 			= scrollFromTop();
	var position			= heightpage/2 + heightpopupblock + scrollFT;
	return position;
}



function mfScrollStatic_Click(event){
    event.preventDefault();
    
//    console.log('event -> ', event.data);
//    console.log('this -> ', this);
//event.data - Модуль с датой
//this - Модуль с датой 
    
        for(let field of event.data.fields){
            if(this[field]){ 
                document.getElementById(field).value = this[field].replace('_', ' ');
                continue;
            }
            if(this[field] != undefined){
                document.getElementById(field).value = '';
            }
        }
   
    
    jQuery('html, body').animate({
        scrollTop: jQuery("#mfForm_"+event.data.id).offset().top-100
    }, 2000);
    return false;
}

function mfOpenModal_Click(event){
    event.preventDefault();
//    console.log('event -> ', event);
//    console.log('event.data.fields -> ', event.data.fields);
//    console.log('this -> ', this);

//event.data - Модуль с датой
//this - Модуль с датой
 
    
        for(let field of event.data.fields){
//            console.log(field,this[field]);
            if(this[field]){ 
                document.getElementById(field).value = this[field].replace('_', ' ');
                continue;
            }
            if(this[field] != undefined){// если пробел.
                document.getElementById(field).value = '';
            }
                
        } 

        
        var modal = "#mfForm_"+event.data.id;
        var overley = "#mfOverlay_"+event.data.id;
        
        var heightpage = jQuery(window).height();
	var heightpopupblock = jQuery(modal).height();
        
        
//    console.log('heightpopupblock -> ', heightpopupblock,'>=',heightpage,'heightpage-',heightpopupblock >= heightpage);
//    console.log('modal -> ', modal);
//    console.log('this.id -> ', event.data.id);
        
	if(heightpopupblock +50 >= heightpage){
		var scrollFT 		= scrollFromTop();//положение прокрутки страницы 
		var positiOnScroll 	= 50;// + scrollFT;
		var positiForOK 	= heightpage/2 - heightpopupblock/2 + scrollFT;
	}else{
		var scrollFT 		= 0;//scrollFromTop();//положение прокрутки страницы 
		var positiOnScroll 	= heightpage/2 - heightpopupblock/2 + scrollFT;
		var positiForOK 	= heightpage/2 - heightpopupblock/2 + scrollFT;
	}
        
        
//    console.log('scrollFT -> ', scrollFT);
//    console.log('positiOnScroll -> ', positiOnScroll);
//    console.log('positiForOK -> ', positiForOK);
//    console.log('modal -> ', modal);
        
	
	jQuery(overley).fadeIn(400, // сначала плавно показываем темную подложку
		function(){ // после выполнения предыдущей анимации
			jQuery(modal) 
				.css('display', 'block') // убираем у модального окна display: none;
				.animate({opacity: 1, top: positiOnScroll}, 200); // плавно прибавляем прозрачность одновременно со съезжанием вниз
	});
    return false;
}
 
 /**
  *  Закрытие модального окна. Присваивается для подложки и кнопки закрыть.
  * @param tag button
  * @returns {undefined}
  */
 //ОК!
function mfCloseModal_Click(event){
    //let id = button.dataset.id; 
        event.preventDefault();
    let id = event.data.id;
    jQuery("#mfForm_"+event.data.id)
               .animate({top: 0}, 200)
               .animate({opacity: 0}, 300, function(){ // после анимации
                    jQuery(this).css('display', 'none'); // делаем ему display: none;
                    jQuery("#mfOverlay_"+id).fadeOut(400); // скрываем подложку
                }); 
}
var runingCloseModalForm = false;
function mfClickCloseModal(){
//    console.log('Click SET Close -> 1 ' );
    if(runingCloseModalForm)
        return;
    runingCloseModalForm = true;
//    console.log('Click SET Close -> 2 ' );
jQuery(function(){// Закрытие окна по клику крестика и фона
    jQuery('.mfOverlay, .mfClose').click(function(close){ 
        close.preventDefault(); 
//    console.log('Click Close -> ', jQuery(this).attr("data-id"));
        var id = jQuery(this).attr('data-id');  
        var modal = "#mfForm_"+id;
        var overley = "#mfOverlay_"+id;
		jQuery(modal).animate({top: 0}, 200);
		jQuery(modal)
			.animate({opacity: 0}, 300, function(){ // после анимации
				jQuery(this).css('display', 'none'); // делаем ему display: none;
				jQuery(overley).fadeOut(400); // скрываем подложку
				}
			);
    });
});
}



/*For Modal Form - Методы для динамических(Модальных) форм*/
/**
 * Скрыть форму после отправки 
 * @param string modal Класс модального окна
 * @param string overley Класс подложки
 * @param string status Клас 
 * @param html response 
 */
function hideBlockFormAfterSend(id,modal,overley,status,response){
	
    jQuery('.mfStatusDone.id'+id).html(response);
	
    var heightpage = jQuery(window).height();
	var heightpopupblock = jQuery('.mfStatusDone.id'+id).height();
	var scrollFT 		= scrollFromTop();
	var positiOnScroll 	= heightpage/2 - heightpopupblock/2 ;//+ scrollFT;
 
// console.log('heightpopupblock высота модалки ',heightpopupblock);
// console.log('scrollFT позиция прокрученого сайта ',scrollFT);
// console.log('positiOnScroll ',positiOnScroll);
 
 
	jQuery('#mfForm_'+id).animate({top: positiOnScroll}, 400, function(){
            jQuery('.mfStatusForm.id'+id).fadeOut();
		setTimeout(function (){ 
			jQuery('#mfForm_'+id)
			// плавно меняем прозрачность на 0 и одновременно двигаем окно вверх
			.animate({top: -positiOnScroll}, 400,
				function(){ // после анимации 
					jQuery(this).fadeOut(); // делаем ему display: none;
					jQuery("#mfOverlay_"+id).fadeOut(); // скрываем подложку
				}
			);	
		}, 10000);//Задержка отображения окна после отправки		
	}); 
}

/**
 * Скрыть и очистить форму после отправки
 * @param string modal 
 * @param string overley
 * @param string status
 * @param html response 
 * @param string textbutton 
 */
function hideAndClearFormAfterSend(id,modal,overley,status,response,textbutton){
 
    jQuery('.mfStatusDone.id'+id).html(response); 

    var heightpage = jQuery(window).height();
    var heightpopupblock = jQuery('.mfStatusDone.id'+id).height();
    var scrollFT 		= scrollFromTop();
    var positiOnScroll 	= heightpage/2 - heightpopupblock/2 + scrollFT;
	
    
    jQuery('#mfForm_'+id).animate({top: positiOnScroll}, 400, function(){
		setTimeout(function (){
			jQuery('#mfForm_'+id)
			// плавно меняем прозрачность на 0 и одновременно двигаем окно вверх
			.animate({top: -positiOnScroll}, 400,
				function(){ // после анимации 
					jQuery(this).fadeOut(); // делаем ему display: none;
					jQuery('#mfOverlay_'+id).fadeOut('', function(){ // скрываем подложку 
						jQuery('.mfStatusDone.id'+id).fadeOut();			
						jQuery('.mfStatusForm.id'+id).fadeIn();
						jQuery('.mfStatusForm.id'+id).get(0).reset();
						jQuery('#mfForm_'+id + ' input[id^=submit]').attr('value', textbutton);
					}); 
					
				}
			);	
		}, 10000);		
	});
}

/*For Static Form - Методы для статических форм*/
/**
 * Скрыть форму перед отправкой
 */
function hideBlockStaticFormAfterSend(id,block,status,response){
//console.log('RESPONse',response);
	jQuery('.mfStatusDone.id'+id).html(response);
    
    jQuery(".mfStatusForm.id"+id).fadeOut(400, function(){
	jQuery('.mfStatusDone.id'+id).fadeIn(400);
    }); // делаем ему display: none; 
}
/**
 * Скрыть и очистить форму перед отправкой
 * @param string block
 * @param string status
 * @param html response
 * @param string textbutton
 * @returns {undefined}
 */ 
function hideAndClearStaticFormAfterSend(id,block,status,response,textbutton){
	
	jQuery('.mfStatusDone.id'+id).html(response); 
	jQuery('.mfStatusForm.id'+id).fadeOut(400, function(){
		jQuery('.mfStatusDone.id'+id).fadeIn(400, function(){
			setTimeout(function (){
				jQuery('.mfStatusDone.id'+id).fadeOut(400, function(){
					jQuery('.mfStatusForm.id'+id).fadeIn(400, function(){
						jQuery('.mfStatusForm.id'+id)[0].reset();
						jQuery('#mfForm_'+id + " input[id^=submit]").attr('value', textbutton);
					}); 
				});
			}, 8000);// Задержка вывода сообщения для статической формы 
		});
	});
} 


/* --------- --------------------------------------- */

    // -------- Send F    
function mfAjaxDoneSuccess(data, status) {
//        this.deb && console.log("Send Success! data:",data);  
        this.deb && console.log("Send Success! status:",status);   
        
        // Вызов пользовательского скрипта из модуля.
        var func_custom = window['funcAfter'+this.id];
        if(func_custom && typeof func_custom === 'function'){
            func_custom.apply(this);//, this.id
        }
 
//console.clear();
//console.log('# '+this.id);
        var posAfterSend = positionAfterSend('#mfForm_'+this.id);
//console.log('posAfterSend',posAfterSend);
//console.log('# '+this.id);
        var params = this;

//console.log(this);
    if(this.type === 'popup'){
        jQuery('#mfForm_'+this.id).animate({top: -posAfterSend}, 400, function(){
            jQuery('.mfStatusForm.id'+params.id+',.modal-footer.id'+params.id+', .mfBeforeText.id'+params.id).fadeOut("500",function(){
                jQuery('.mfStatusDone.id'+params.id).fadeIn("500");
											
                if(params.clearaftersend){////Очищать форму $param->clearaftersend
											
                    hideAndClearFormAfterSend(
                        params.id,
					'#mfForm_'+params.id,
					'#mfOverlay_'+params.id,
					'.mfStatusDone.id'+params.id,
					data,
					jQuery('input#submit'+params.id).data('ready')//textSubmitButton
			);					
                }else{
											
                    hideBlockFormAfterSend(
                        params.id,
					'#mfForm_'+params.id,
					'#mfOverlay_'+params.id,
					'.mfStatusDone.id'+params.id,
					data
                    );
                }
            });
        });
    }
    if(this.type === 'static'){
        
        jQuery('.mfStatusForm.id'+params.id+',.static-footer.id'+params.id+', .mfBeforeText.id' + params.id).fadeOut("500",function(){
		

            jQuery('.mfStatusDone.id'+params.id).fadeIn("500");
									
            if(params.clearaftersend){ 					
                hideAndClearStaticFormAfterSend(
                    params.id,
                    '#mfForm_'+params.id,
                    '.mfStatusDone.id'+params.id,
                    data,
                    jQuery('input#submit'+params.id).attr('value')
                );
            }else{ 					
                hideBlockStaticFormAfterSend(
                    params.id,
                    '#mfForm_'+params.id,
                    '.mfStatusDone.id'+params.id,
                    data
                );						
            }
            mfScrollStatic_Click.call(params,{data:params,first:true,preventDefault:function(){
            params.deb && console.log('🏆 mfScrollStatic_Click ', "#mfForm_form_"+params.id, params); return true; }});
        });
    }
    }
    
    function mfButtonSubmit_Click(e){
//        let params = e.data;
//        let e = {data:this};
         //console.log('🏆 func_custom', e);
        //return;
            var itemid =0;
    
    for(let clss of document.body.classList){
        if(clss.toString().substr(0,7)==='itemid-'){
            itemid = clss.toString().substr(7);
        }
    }
        //----------
//        var fields = params.fields;
//        var textSubmitButton = $('input#submit'+e.data.id).attr('value');
        if(e.first)
            e.preventDefault();
         
        // Вызов пользовательского скрипта из модуля.
        let func_custom = window['funcBefore'+e.data.id];
// console.log('🏆 func_custom', func_custom);
        if(func_custom && typeof func_custom === 'function'){
            func_custom.apply(e.data);
        }
// console.log('🏆 mfButtonSubmit_Click ', "#mfForm_form_"+e.data.id, e.data); 
//        jQuery( "#mfForm_form_"+e.data.id ).validate();
//        
//        return;
//console.log('jQuery.validator.messages',jQuery.validator.messages);
        jQuery( "#mfForm_form_"+e.data.id ).validate({
            
//            messages: jQuery.validator.messages,
            debug : false,
//            showErrors: function(errorMap, errorList) { 
//                console.log("Your form contains "
//                    + this.numberOfInvalids()
//                    + " errors, see details below."
//                    + this.defaultShowErrors(),errorMap,errorList);
//            },
            invalidHandler:function(event, validator){
                console.log('👎 _validator');
                console.log('👎 _validator',validator);
            },
            submitHandler: function(form,event){
                event.preventDefault();
//                jQuery(form).submit(function(e) {
//                     e.preventDefault();
//                });
//                form.preventDefault();
//                console.log('🏆 Validated!!!!');
//                console.log('🏆 Validated!!!! data', e.data);
//                console.log('🏆 Validated!!!! Event', event);
//                console.log('🏆 Validated!!!! Form', form);
                
//                throw new Error("Something went badly wrong!");
                jQuery('#submit_'+e.data.id).attr('value',jQuery('#submit_'+e.data.id).data('sending'))
                        .css('text-transform','none').css('transform','none').addClass('active'); //Тект кнопки при отправке
//                return false;
/*
 * var text1251 = $('input[name=text1251]').val();
 * var telephone2251 = $('input[name=telephone2251]').val();
 */
/*
 * '0251':0251,
 * 'text1251':text1251,
 * 'telephone2251':telephone2251,
 */



                var form = document.getElementById('mfForm_form_'+e.data.id)
                var data = new FormData(form);//  mfForm_form_249
                
//                data.append('method     ', 'getForm');
                data.append('option', 'com_ajax');
                data.append('module', 'multi_form');
                data.append('format', 'raw');//raw  json  debug
                data.append('id', e.data.id);
                data.append('page', document.location.href);
                data.append('title', document.title);
                data.append('Itemid', itemid);
//                console.log('Itemid', itemid);
//                var data = {
//                                //'method':'getForm',
//                                option      : 'com_ajax',
//				module      : 'multi_form',
//				format      : 'raw',//raw  json  debug
//				id          : e.data.id,
//				currentPage : document.location.href,
//                                title       : document.title
//                };
                


//jQuery('#file')[0].files
//jQuery("#file").prop('files')[0]
                 

//data.append('img', $input.prop('files')[0]);
//data.append('file-'+i, file);
//request = fd;
//-----------------------                                
                //Собираем данные с полей формы - js формирующий данные
		// Список наименований полей из XML 
                for (var field of e.data.fields) {
                    if(field.substring(0,4)=='file'){
                        for(let file of  document.getElementById(field).files){//jQuery('#'+field)[0].files
                            //data[field] = jQuery('.input[name='+field+']').val();
                            data.append(field, file);//+'-'+i
                        }
                    }else{
                          //data[field] = jQuery('#'+field).val();//data[field] = jQuery('.input[name='+field+']').val();
//                        data.append(field, jQuery('#'+field).val());
                    }
                }
//-----------------------                
                
               // $( this ).serializeArray() ); // https://api.jquery.com/serializeArray/
//                console.log('e.data.fields',e.data.fields);
//                console.log('request',data);
            
                
            var url = window.location.origin+'/index.php';
                url = document.baseURI + 'index.php';
                e.data.deb && console.log('Ajax request ModuleID:',e.data.id,' ',data);
                jQuery.ajax({type:'POST',url:url,dataType:'html',data:data,context:e.data,cache:false,contentType:false,processData:false})
                        .done(mfAjaxDoneSuccess).fail(mfAjaxFailForm);
            }
        });
        
//        e.preventDefault();
    }

// -------- Load F 

    function mfAjaxDoneForm(data, status) {  
//        var id = jQuery(this).data('id');
//        var deb = jQuery(this).data('deb');
//        var type = jQuery(this).data('type');
        this.deb && console.log('🏆 Module id:'+this.id+' Tag:'+this.tag+' Type:'+this.type+' - Load form Success! - Done! status:',status,' ',this);
//        console.log(this);
//        console.log(data);
//            console.log('🏆'+this.id);
//            console.log('🏆'+this.id);
//            console.log('#'+this.button, this.type);
//            console.log(this.buttons);
        if(this.type=='popup'){
            jQuery('body').append(jQuery(data));
            jQuery('#mfClose_'+this.id).click(this,mfCloseModal_Click);
            jQuery('#mfOverlay_'+this.id).click(this,mfCloseModal_Click);
            if(this.buttons.length > 0){
            for(let btn of this.buttons){
//                 console.log(btn);
                jQuery(btn).click(this,mfOpenModal_Click);
            }} 
        }else{
            jQuery('#mod_'+this.id).append(jQuery(data));
            if(this.buttons.length > 0){
            for(let btn in this.buttons){
//                console.log(btn);
                jQuery(btn).click(this,mfScrollStatic_Click);
            }}
        } 
        this.deb && console.log('🏆 ButtonSubmit id:'+this.id+' Tag:'+this.tag+' Type:'+this.type+' - Load form Success! - Done! status:',status,this);
        
        mfButtonSubmit_Click.call(this,{data:this,first:true,preventDefault:function(){
        this.deb && console.log('🏆 mfButtonSubmit_Click ', "#mfForm_form_"+this.id, this); return true; }});

        jQuery('input#submit_'+this.id).each(function(i,el){
            //this.deb && 
//                    console.log('🏆 OnClick for Submit ', 'input#submit_'+this.id,el, this);
//                    console.log(123, i);
        }).click(this,mfButtonSubmit_Click);
        
//        jQuery('#mfForm_form_'+this.id +' input').inputmask();
        console.log('🏆 Module id:'+this.id+' Tag:'+this.tag+' Type:'+this.type+' - Load form Success! - Done! status:',status);
    }
    
    function mfAjaxFailForm(jqXHR, status,errorThrown) {  
        this.deb && console.log('👎 Module id:'+this.id+' Tag:'+this.tag+' Type:'+this.type+' - Load form Fail! - Disabled button! status:',status,' ',this,jqXHR);//, errorThrown,jqXHR
//        jQuery('.button.id'+this.id).hide();
            
        jQuery('#'+this.button).hide();
    }
    
/*
 * Получение объекта всех значений из хеша URL
 * @returns {Boolean|mfGetUrlHash.hash}
 */
function mfGetUrlHash(url){
    
    let is_mod = false;
    let id = 0;
    
    let hash = {};
    Object.assign(hash, jQuery.url('#',url));
    
//    console.log('hash',hash);
//    console.log('url',jQuery.url());
    let str_hash =jQuery.url('hash',url) || '';
    let amp = str_hash.indexOf("&");
    
    amp < 1 && (amp = undefined); //str_hash.length
//console.log(amp,' ',str_hash);
//    console.log(id);
    id = str_hash.startsWith("mfForm_form_")? str_hash.substring(12,amp):id;
    id = str_hash.startsWith("mfForm_")? str_hash.substring(7,amp): id;
    id = str_hash.startsWith("mod_")? str_hash.substring(4,amp): id;
    id = str_hash.startsWith("mod")? str_hash.substring(3,amp): id;
    hash.id = id || false;
    hash.path       = jQuery.url('path',url);
    hash.hostname   = jQuery.url('hostname',url);
    hash.query      = jQuery.url('query',url);
    hash.url        = jQuery.url('',url);
    
    //console.log('%c '+id+' ! ','background: #222; color: #bada55');
//    console.warn('id:',id,' amp:',amp,'  ',str_hash,'   ',url);
//    console.log('hash',id,hash,url);
//    console.log(url);
    
    return hash;
}
/**
 * Получение данных полей из модуля
 * @param {number} id
 * @returns {Object|Boolean}
 */
function mfGetModuleById(id){
    return (jQuery('.mfForm.id'+id).data()) || false;
}    
/**
 * Переход, перемотка к форме, или  открытие формы диалогового окна
 * @param {object} module
 * @returns {object}
 */
function mfGotoModule(module, hash){  
    for(let field of module.fields){
        if(hash[field]){ 
            document.getElementById(field).value = hash[field];
        }
    }
    
    if(module.type === 'static')
        mfScrollStatic_Click.call(module,{data:module,first:true,preventDefault:function(){
            module.deb && console.log('🏆 mfScrollStatic_Click ', "#mfForm_form_"+module.id, module); return true; }});
    
    if(module.type === 'popup')
        mfOpenModal_Click.call(module,{data:module,first:true,preventDefault:function(){
            module.deb && console.log('🏆 mfOpenModal_Click ', "#mfForm_form_"+module.id, module); return true; }});
}
/**
 * 
 * @returns {undefined}
 */
function mfGetAllActions(){
    return (jQuery('a:not(.mfGo)')
    .filter(function(){
        let href = this.getAttribute("href");
        if(!href)
            return false;
        if(href.indexOf("#")===-1 || href.length < 4)
            return false;
        return true; 
    }).map(function(){let hash = mfGetUrlHash(this.getAttribute("href")) ; hash.control=this; return hash;
    }).filter(function(){return this.id;
    }).get()) ;
}
function mfGetAllModules(){
    let modules = {};
    let mods = jQuery('.mfForm').map(function(){
        let data = jQuery(this).data();
        data.control = this;
        return data;});
    
    for(let module of mods){
        if(module.type)
        modules[module.id] = module;
    }
    return modules;
    return mods;
}
function mfAjaxCompleteAllForm(p1){ 
//    console.log('jQuery.validator.messages',jQuery.validator.messages );
//    jQuery("form").validate({messages:jQuery.validator.messages}); 
//    jQuery.getScript('modules/mod_multi_form/js/messages.min.js');
  
//    jQuery.getScript(document.location.origin+'/media/editors/tinymce/tinymce.min.js',function(){    });
    var tinyeditor = ()=>false;
    if(typeof tinymce === 'object'){
        tinyeditor = function(){
        tinymce.init({  selector: '.joomla-editor-tinymce',menubar: false,  
            toolbar: 'undo redo | formatselect | bold italic backcolor strikethrough | removeformat  pastetext | alignleft aligncenter alignright alignjustify   | bullist numlist table outdent indent ',
            plugins: ['advlist autolink lists link image charmap print preview anchor',    'searchreplace visualblocks code fullscreen',    'insertdatetime media table paste code   wordcount']});
        };
    }
    var userLang = navigator.language || navigator.userLanguage; 
    let edit_path = Joomla.iframeButtonClick ? '/media/vendor/tinymce/tinymce.min.js' :
            document.location.origin+'/media/editors/tinymce/tinymce.min.js';
    let lang_path = Joomla.iframeButtonClick ? '/media/vendor/tinymce/langs/'+userLang+'.js' :
            document.location.origin+'/media/editors/tinymce/langs/'+userLang+'.js';
//    console.log(lang_path);
    jQuery.getScript(edit_path).always(_ => jQuery.getScript(lang_path).always(tinyeditor));
    


    
    let hash = mfGetUrlHash(); // URL
//console.log('HASH',hash);
    
    let module = hash.id? mfGetModuleById(hash.id): false; // Модуль из URL
    module && mfGotoModule(module,hash);// Переход к модулю указанному в URL и присвоение полей
    
    let actions = mfGetAllActions();
    let modules = mfGetAllModules();
    
//    console.log('actions ',actions);
//    console.log('modules ',modules);
//    console.log('hostname','path','query','id',' ------ Actions Count:',actions.length);
//    console.log('HASH ',hash);
    for(let action of actions){ 
//        var action = actions[i];
        if(! (action.id in modules))
            continue;

        let module = modules[action.id];
        action.module=module;
//        console.log(i+' action ',action);
(        
        action.url.startsWith("#") ||
        (hash.hostname===action.hostname || action.hostname==='') &&
        (hash.path    ===action.path || ( ['','/','index.php','/index.php'].includes(hash.path) &&  ['','/','index.php','/index.php'].includes(action.path) )   ) &&
        hash.query   ===action.query
)
        //&& ((console.log(' --------Type==PopUp',modules[action.id].type==='popup'))|| true )
        //&& ((console.log(' --------action',action.id,modules[action.id].type,action))|| true )
        &&
        (
            (
                //(console.log(' -------Set-ClickStatic',action)||true) &&
                (modules[action.id].type==='static') && 
                (   (jQuery(action.control).click(function(e){e.preventDefault();mfScrollStatic_Click.call(action,{data:modules[action.id],first:true,preventDefault:function(){ return true; }});return false;})
                    )|| true)
            )
            ||
            (
                //(console.log(' -------Set-ClickPopUp',action)||true) && 
                (modules[action.id].type==='popup')  && 
                (   (jQuery(action.control).click(function(e){e.preventDefault();mfOpenModal_Click.call(action,{data:modules[action.id],first:true,preventDefault:function(){ return true; }});return false;})
                    )|| true)
            )
        )
        //&& true 
        //&& console.log(' --------action',action);
        ;
        //ПРИСВОИТЬ КЛИК для ссылок этой страницы
        
             
    }
    return;
//    console.log('actions ',actions);
//    console.log(p1);
//        console.log('🏆🏆🏆🏆🏆🏆🏆🏆 Module :',this);
        //$( this ).serializeArray()
        
	//var hash = location.hash.substring(1); 
        
}

jQuery(function(){
    
    var mfButtons = {};
    var itemid =0;
    
    for(let clss of document.body.classList){
        if(clss.toString().substr(0,7)==='itemid-'){
            itemid = clss.toString().substr(7);
        }
    }
    
    
    jQuery.when(...jQuery('.mfForm')//.get().reverse()
        .filter(function( i, form_mod ){
            var params = jQuery(form_mod).data();
            if(!params.id){
                return false;
            }
            
            params.button = jQuery(form_mod).get(0).id; 
            params.tag = jQuery(form_mod).get(0).tagName;
            
//            console.log(i,'-form ',params.id,' ',params.tag,' ----------', params.button );
            
            if(!(params.id in mfButtons)){
                mfButtons[params.id] = [];
            }
            
            if(['a','button','A','BUTTON'].includes(params.tag) ){ 
                if(mfButtons[params.id]){
                    mfButtons[params.id].push(form_mod);//params.button
                }
            }
            
            if('mod_'+params.id!==params.button)
                return false;
            
            params.buttons = mfButtons[params.id];
            form_mod.params = params;
            return true;
        })
        .map(function(index,form_mod){//.popup
//console.log(index);
//console.log(form_mod);
//            var params = form_mod.params; 
//            form_mod.params.deb && console.log('moduleID:'+form_mod.params.id,form_mod.params);
            //params.buttons = mfButtons[params.id];
//            params.deb = true;
//            console.log('params:',params);
//            params.id = jQuery(form_mod).data('id');
//            params.deb = jQuery(form_mod).data('deb');
//            params.type = jQuery(form_mod).data('type');
                
            var url = window.location.origin+'/index.php';
                url = document.baseURI + 'index.php';
//console.log(url);
            var request = {id:form_mod.params.id,format:'raw',module:'multi_form',option:'com_ajax',method:'getForm',Itemid:itemid};
            return jQuery.ajax({type:'POST',url:url,dataType:'html',data:request,context:form_mod.params}).done(mfAjaxDoneForm).fail(mfAjaxFailForm);
        })).done(mfAjaxCompleteAllForm);
//    console.log(mfButtons);
         
    
//        console.log('mfButtons:',mfButtons);
        //hidden text textarea editor telephone email select radio checkbox color 
});